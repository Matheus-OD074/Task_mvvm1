package com.example.tasks_mvvm.dto

data class TaskDto(
    val id: Long,
    val description: String,
    val isCompleted: Boolean
)
