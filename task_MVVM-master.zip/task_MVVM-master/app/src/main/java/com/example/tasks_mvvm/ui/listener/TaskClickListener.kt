package com.example.tasks_mvvm.ui.listener

interface TaskClickListener  {
    fun clickDone(position: Int)
}